from __future__ import annotations
import os
from fastapi import FastAPI, Response, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv

from .csv_logger import CsvRotatingWriter
from .gpio_counter import Z_SEND_ENABLED, PulseCounter
from .z_telegram import ZSender
from .sysinfo import get_uptime_seconds, get_cpu_temp_c, self_check
from .version import __version__

load_dotenv()

DATA_DIR = os.getenv("DATA_DIR", "./data")
MAX_CSV_BYTES = int(os.getenv("MAX_CSV_BYTES", 10_000_000))
BACKUP_COUNT = int(os.getenv("BACKUP_COUNT", 5))
Z_SEND_ENABLED = os.getenv("Z_SEND_ENABLED", "1") == "1"
Z_SEND_HOST = os.getenv("Z_SEND_HOST", "127.0.0.1")
Z_SEND_PORT = int(os.getenv("Z_SEND_PORT", 9787))

csv_writer = CsvRotatingWriter(DATA_DIR, MAX_CSV_BYTES, BACKUP_COUNT)
z_sender = ZSender(Z_SEND_HOST, Z_SEND_PORT) if Z_SEND_ENABLED else None
counter = PulseCounter(csv_writer, z_sender)

app = FastAPI(title="Pi5 Pulse Logger (M1)", version=__version__)
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "../static"), html=True), name="static")

class StatusDTO(BaseModel):
    running: bool
    seq: int
    count: int
    rate_hz: float
    timestamp: str
    last_pulse_age_sec: float | None
    z_value: float | None
    uptime_sec: float
    cpu_temp_c: float | None
    self_check: str

@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(os.path.dirname(__file__), "../static/index.html"), "r", encoding="utf-8") as f:
        return HTMLResponse(f.read())

@app.post("/api/start")
def api_start():
    started = counter.start()
    return {"ok": True, "started": started}

@app.post("/api/stop")
def api_stop():
    stopped = counter.stop()
    return {"ok": True, "stopped": stopped}

@app.get("/api/status", response_model=StatusDTO)
def api_status():
    s = counter.status()

    return StatusDTO(
        running=s.running,
        seq=s.seq,
        count=s.count,
        rate_hz=s.rate_hz,
        timestamp=s.timestamp,
        last_pulse_age_sec=s.last_pulse_age_sec,
        z_value=s.z_value,
        uptime_sec=get_uptime_seconds(),
        cpu_temp_c=get_cpu_temp_c(),
        self_check=self_check(s.running, s.last_pulse_age_sec)
    )

@app.get("/api/csv")
def api_csv():
    path = csv_writer.path()
    if not os.path.exists(path):
        raise HTTPException(404, "CSV not found")
    return FileResponse(path, media_type="text/csv", filename=os.path.basename(path))