from __future__ import annotations
import json, socket, time


class ZSender:
    def __init__(self, host: str, port: int):
        self.addr = (host, port)
        self.seq = 0
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


    def emit(self, z_value, N: int, quality: str | None = None):
        self.seq += 1
        q = quality or ("OK" if (z_value is not None) else "LOW")
        payload = {
            "seq": self.seq,
            "z": None if z_value is None else float(z_value),
            "N": int(N),
            "quality": q,
        }
        self.sock.sendto(json.dumps(payload).encode("utf-8"), self.addr)