from __future__ import annotations
import os, io, shutil
from datetime import datetime, timezone
from threading import RLock

class CsvRotatingWriter:
    COLUMNS = ["seq", "count", "rate_hz", "status", "timestamp"]

    def __init__(self, data_dir: str, max_bytes: int = 10_000_000, backup_count: int = 5):
        self.data_dir = data_dir
        os.makedirs(self.data_dir, exist_ok=True)
        self.max_bytes = max_bytes
        self.backup_count = backup_count
        self._path = os.path.join(self.data_dir, "run.csv")
        self._lock = RLock()
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self._path) or os.path.getsize(self._path) == 0:
            with open(self._path, "w", encoding="utf-8", newline="") as f:
                f.write(",".join(self.COLUMNS) + "\n")
    
    def path(self) -> str:
        return self._path
    
    def rotate_if_needed(self):
        if os.path.getsize(self._path) < self.max_bytes:
            return
        
        for i in range(self.backup_count, 0, -1):
            src = f"{self._path}.{i}"
            dst = f"{self._path}.{i+1}"

            if os.path.exists(src):
                if i == self.backup_count:
                    os.remove(src)
                else:
                    os.replace(src, dst)
        
        shutil.copy2(self._path, f"{self._path}.1")
        open(self._path, "w").close()
        self._ensure_header()

    def write_row(self, seq: int, count: int, rate_hz: float, status: str):
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        line = f"{seq},{count},{rate_hz:.6f},{status},{ts}\n"
        with self._lock:
            self.rotate_if_needed()
            with open(self._path, "a", encoding="utf-8", newline="") as f:
                f.write(line)
