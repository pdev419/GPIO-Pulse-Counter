from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass
from typing import Optional, Deque
from collections import deque
from datetime import datetime, timezone

from dotenv import load_dotenv

load_dotenv()

GPIO_PIN = int(os.getenv("GPIO_PIN", 18))
TIME_WINDOW_SEC = float(os.getenv("TIME_WINDOW_SEC", 1.0))
REF_WINDOW_PULSES = int(os.getenv("REF_WINDOW_PULSES", 100))

Z_SEND_ENABLED = os.getenv("Z_SEND_ENABLED", "1") == "1"
Z_SEND_INTERVAL_SEC = float(os.getenv("Z_SEND_INTERVAL_SEC", 1.0))
Z_SEND_HOST = os.getenv("Z_SEND_HOST", "127.0.0.1")
Z_SEND_PORT = int(os.getenv("Z_SEND_PORT", 9787))

EDGE_MODE = os.getenv("EDGE_MODE", "RISING").upper()
DEBOUNCE_US = int(os.getenv("DEBOUNCE_US", "0"))

FORCE_MOCK = os.getenv("FORCE_MOCK", "0") == "1"
MOCK_HZ = float(os.getenv("MOCK_HZ", 10.0))
MOCK_JITTER = float(os.getenv("MOCK_JITTER", 0.2))

try:
    import lgpio
    _HAVE_LGPIO = True
except Exception:
    lgpio = None
    _HAVE_LGPIO = False


@dataclass
class Status:
    running: bool
    seq: int
    count: int
    rate_hz: float
    timestamp: str
    last_pulse_age_sec: Optional[float]
    z_value: Optional[float]


class PulseCounter:
    def __init__(self, csv_writer, z_sender=None):
        self.csv = csv_writer
        self.z_sender = z_sender

        self._lock = threading.RLock()
        self._running = False
        self._seq = 0
        self._count_total = 0
        self._window_count = 0
        self._last_rate_hz = 0.0
        self._t_window = time.monotonic()
        self._last_pulse_time: Optional[float] = None

        self._stop_evt = threading.Event()
        self._thread: Optional[threading.Thread] = None

        self._chip = None
        self._cb = None

        self._z_ref_times: Deque[float] = deque(maxlen=REF_WINDOW_PULSES + 1)
        self._z_last_emit = 0.0

    def start(self) -> bool:
        with self._lock:
            if self._running:
                return False
            self._stop_evt.clear()
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._running = True
            self._thread.start()
            return True

    def stop(self) -> bool:
        with self._lock:
            if not self._running:
                return False
            self._stop_evt.set()

        if self._thread:
            self._thread.join(timeout=5)

        with self._lock:
            self._running = False
            self._thread = None

            if self._cb is not None:
                try:
                    cancel = getattr(self._cb, "cancel", None)
                    if callable(cancel):
                        cancel()
                except Exception:
                    pass
                self._cb = None

            if self._chip is not None:
                try:
                    if hasattr(lgpio, "gpio_free"):
                        lgpio.gpio_free(self._chip, GPIO_PIN)
                except Exception:
                    pass
                try:
                    lgpio.gpiochip_close(self._chip)
                except Exception:
                    pass
                self._chip = None

        return True

    def _configure_lgpio(self) -> None:
        self._chip = lgpio.gpiochip_open(0)

        edge_const = {
            "RISING": getattr(lgpio, "RISING_EDGE", 1),
            "FALLING": getattr(lgpio, "FALLING_EDGE", 2),
            "BOTH": getattr(lgpio, "BOTH_EDGES", 3),
        }.get(EDGE_MODE, getattr(lgpio, "RISING_EDGE", 1))

        lgpio.gpio_claim_alert(self._chip, GPIO_PIN, edge_const, 0)

        if DEBOUNCE_US > 0 and hasattr(lgpio, "gpio_set_debounce_micros"):
            try:
                lgpio.gpio_set_debounce_micros(self._chip, GPIO_PIN, DEBOUNCE_US)
            except Exception:
                pass

        self._cb = lgpio.callback(self._chip, GPIO_PIN, edge_const, self._edge_cb)

    def _edge_cb(self, chip, gpio, level, ticks) -> None:
        if level not in (0, 1):
            return

        now = time.monotonic()
        self._last_pulse_time = now
        self._count_total += 1
        self._window_count += 1
        self._z_ref_times.append(now)

    def _run(self) -> None:
        use_mock = FORCE_MOCK or not _HAVE_LGPIO
        if not use_mock:
            self._configure_lgpio()
        else:
            import random
            def _mock():
                base = 1.0 / max(0.1, MOCK_HZ)
                while not self._stop_evt.is_set():
                    jitter = 1.0 + (random.uniform(-MOCK_JITTER, MOCK_JITTER))
                    time.sleep(max(0.0005, base * jitter))
                    self._edge_cb(None, GPIO_PIN, 1, 0)
            threading.Thread(target=_mock, daemon=True).start()

        self._t_window = time.monotonic()
        self._z_last_emit = time.monotonic()

        while not self._stop_evt.wait(0.01):
            now = time.monotonic()

            if (now - self._t_window) >= TIME_WINDOW_SEC:
                dt = now - self._t_window
                rate = (self._window_count / dt) if dt > 0 else 0.0
                self._last_rate_hz = rate
                self._seq += 1
                self.csv.write_row(
                    seq=self._seq,
                    count=self._count_total,
                    rate_hz=rate,
                    status="RUNNING",
                )
                self._window_count = 0
                self._t_window = now

            if Z_SEND_ENABLED and (now - self._z_last_emit) >= Z_SEND_INTERVAL_SEC:
                z = self._compute_z()
                if self.z_sender:
                    self.z_sender.emit(z, REF_WINDOW_PULSES)
                self._z_last_emit = now

        self._seq += 1
        self.csv.write_row(
            seq=self._seq,
            count=self._count_total,
            rate_hz=self._last_rate_hz,
            status="STOPPED",
        )

    def _compute_z(self) -> Optional[float]:
        if len(self._z_ref_times) < (REF_WINDOW_PULSES + 1):
            return None
        t_old = self._z_ref_times[0]
        t_new = self._z_ref_times[-1]
        dt = t_new - t_old
        if dt <= 0:
            return None

        ref_rate = REF_WINDOW_PULSES / dt
        inst_rate = self._last_rate_hz
        if ref_rate <= 0:
            return None

        return inst_rate / ref_rate

    def status(self) -> Status:
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        last_age: Optional[float] = None
        if self._last_pulse_time is not None:
            last_age = max(0.0, time.monotonic() - self._last_pulse_time)

        return Status(
            running=self._running,
            seq=self._seq,
            count=self._count_total,
            rate_hz=self._last_rate_hz,
            timestamp=ts,
            last_pulse_age_sec=last_age,
            z_value=self._compute_z(),
        )
