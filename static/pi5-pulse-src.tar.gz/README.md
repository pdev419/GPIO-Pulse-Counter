# Pi5 Pulse Logger (M1)

**What this does**  
This Raspberry Pi 5 app counts electrical pulses on **GPIO18**, shows live status in your browser, and lets you **download clean CSV logs**. It also makes a simple plot for a 60-minute test and can send a tiny **“Z-telegram”** JSON message once per second.

---

## Quick Start (on the Pi)

1) **Install**
```bash
sudo apt update
sudo apt install -y python3-pip python3-venv python3-lgpio
```

2) **Set up the project**
```bash
cd ~/pi5-pulse-m1
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

3) **Run the web app**
```bash
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open a browser to: **http://<pi-ip>:8000**

---

## Using the Web UI

- **Start** – begins logging (exactly one logger instance)
- **Stop** – ends logging cleanly
- **Status** – shows Running/Stopped, live count, rate (Hz), Z, and a self-check line
- **Download CSV** – saves the current log

**CSV columns (fixed):**
```
seq, count, rate_hz, status, timestamp
```
`timestam﻿p` is **UTC ISO-8601** (e.g., `2025-09-25T10:15:30Z`). Logs auto-rotate to protect storage.

---

## 60-Minute Run (acceptance)

1) Click **Start** and leave it running ~60 minutes  
2) Click **Stop**, then **Download CSV**  
3) Create a plot PNG:
```bash
python3 analysis/plot_run.py --csv data/run.csv --out run.png
```
Deliver **run.png** and the CSV.

---

## Z-Telegram (optional)

Sends tiny JSON like:
```json
{"seq":123,"z":0.9987,"N":100,"quality":"OK"}
```
Receiver:
```bash
python3 receiver.py
```
(Host/port via `.env`.)

---

## Configuration (`.env`)

**GPIO & sampling**
```
GPIO_PIN=18
EDGE_MODE=RISING        # RISING | FALLING | BOTH
DEBOUNCE_US=0           # microseconds glitch filter
TIME_WINDOW_SEC=1       # rate update interval (s)
REF_WINDOW_PULSES=100   # size of Z reference window
```

**CSV rotation**
```
DATA_DIR=./data
MAX_CSV_BYTES=10485760
BACKUP_COUNT=5
```

**Z-telegram**
```
Z_SEND_ENABLED=1
Z_SEND_INTERVAL_SEC=1
Z_SEND_HOST=127.0.0.1
Z_SEND_PORT=9787
```

**Mock mode (no wiring)**
```
FORCE_MOCK=1
MOCK_HZ=10
MOCK_JITTER=0.2
```

Edit `.env`, save, and restart the app.

---

## Testing Without External Hardware

**Loopback (recommended):**  
Run your pulse generator on **GPIO23** (output) and jumper **23 → 18** (input). Keep the app on GPIO18.  
> Don’t let two processes own the same pin; you’ll get “GPIO busy”.

**Mock mode:**  
Set `FORCE_MOCK=1` to simulate pulses in software (no jumper needed).

---

## Where files live

- CSV logs: `./data/` (auto-rotated)  
- Plot PNG: path you pass to `--out` in `analysis/plot_run.py`

---

## Acceptance Checklist (mapped to M1)

- **Start/Stop/Status**: start launches exactly one logger; repeated Start doesn’t duplicate; Status shows running/stopped + count + rate.  
- **CSV**: header + exact columns `seq,count,rate_hz,status,timestamp`; timestamp is **UTC ISO-8601**; CSV download link exists; rotation prevents storage fill.  
- **60-minute run**: completes without crashes; deliver CSV + one PNG plot.  
- **README**: this file (≤1 page non-technical guidance, tools pinned).  
- **Delivery & rights**: Source + README (ZIP), permissive OSS only; THIRD_PARTY_NOTICES included; no router/network changes.

---

## Tools (pinned)

FastAPI, Uvicorn, pandas, matplotlib, **lgpio** (libgpiod), python-dotenv.  
Versions are pinned in `requirements.txt` for reproducibility.  
No router/network changes are required. Use **SSH key-only** access to the Pi.

---

## Troubleshooting

- **GPIO busy**: Another process owns the pin. Use a different output pin for your generator (e.g., 23) and jumper to 18, or stop the other process. Check with `gpioinfo`.
- **Permission denied** on `/dev/gpiochip0`: Run with `sudo` or add your user to the `gpio` group and re-login.
- **No pulses**: Verify wiring, set `EDGE_MODE=RISING`, try `DEBOUNCE_US=1000`, or enable `FORCE_MOCK=1`.
- **Very high rates**: This PoC targets stable lower-rate operation; extremely high frequencies may exceed Python callback limits.

---

## License & Third-Party

- Project: **MIT** (see `LICENSE`)  
- Third-party notices: see `THIRD_PARTY_NOTICES` (FastAPI, Uvicorn, pandas, matplotlib, lgpio, python-dotenv)
